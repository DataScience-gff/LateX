# fancyBook
The fancyBook is a package for LaTeX
